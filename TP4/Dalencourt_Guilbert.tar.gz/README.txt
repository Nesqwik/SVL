Test de base
  - Création d'un utilisateur (nom prenom login)
      - Le login est unique, création
          - Simple création d'un utilisateur
          - Insertion d'un utilisateur dans le catalogue des utilisateurs
          - Insertion de plusieurs utilisateurs dans le catalogue des utilisateurs
      - Le login n'est pas unique, erreur

  - Génération d'un login à partir du nom prénom
      - Le login est unique, création
      - Le login n'est pas unique erreur
      - Le login respecte le format normal
          - test aux bornes (input > 8 < 8 = 8)
      - Test de génération du plan A
          - Respect du format
      - Test de génération du plan B
          - Respect du format
