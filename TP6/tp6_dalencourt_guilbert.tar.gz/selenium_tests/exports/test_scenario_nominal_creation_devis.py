# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import unittest, time, re

class TestScenarioNominalCreationDevis(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.driver.implicitly_wait(30)
        self.base_url = "http://localhost:8080"
        self.verificationErrors = []
        self.accept_next_alert = True

    def test_scenario_nominal_creation_devis(self):
        driver = self.driver
        driver.get(self.base_url + "/")
        driver.find_element_by_link_text("Creer devis").click()
        driver.find_element_by_name("reference").clear()
        driver.find_element_by_name("reference").send_keys("00010")
        Select(driver.find_element_by_name("customer")).select_by_visible_text("Aquamacs SARL")
        driver.find_element_by_name("amount").clear()
        driver.find_element_by_name("amount").send_keys("20000")
        driver.find_element_by_css_selector("input[type=\"submit\"]").click()
        driver.find_element_by_link_text("00010").click()
        self.assertEqual("Devis 00010", driver.find_element_by_css_selector("body > p:nth-child(1)").text)
        self.assertEqual("Montant: 20000", driver.find_element_by_css_selector("body > p:nth-child(3)").text)

    def is_element_present(self, how, what):
        try: self.driver.find_element(by=how, value=what)
        except NoSuchElementException as e: return False
        return True

    def is_alert_present(self):
        try: self.driver.switch_to_alert()
        except NoAlertPresentException as e: return False
        return True

    def close_alert_and_get_its_text(self):
        try:
            alert = self.driver.switch_to_alert()
            alert_text = alert.text
            if self.accept_next_alert:
                alert.accept()
            else:
                alert.dismiss()
            return alert_text
        finally: self.accept_next_alert = True

    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
