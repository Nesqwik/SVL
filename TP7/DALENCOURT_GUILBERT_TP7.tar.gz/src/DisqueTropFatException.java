/**
 * DisqueTropFatException <br/>
 * Created by dalencourt on 13/03/17.
 */
public class DisqueTropFatException extends Exception {
    //@ public represents _stackTrace <- this.getStackTrace();
}
