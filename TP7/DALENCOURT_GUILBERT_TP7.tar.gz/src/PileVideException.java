/**
 * PileVideException<br/>
 * Created by dalencourt on 13/03/17.
 */
public class PileVideException extends Exception {
    //@ public represents _stackTrace <- this.getStackTrace();
}
